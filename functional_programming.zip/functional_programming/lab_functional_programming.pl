?- use_module(library(lambda)).
?- use_module(library(clpq)).

sum(Z, G) :-
    { G =:= Z + Z }.

mul(Z, G) :-
    { G =:= Z * Z }.

f(X, Y, G) :- 
    G = (\Z^R^ (
        call(X, Z, R1),
        call(Y, Z, R2),
        { R =:= R1 + R2 }
    )).
